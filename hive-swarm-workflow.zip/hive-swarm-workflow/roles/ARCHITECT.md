# Rôle : Architecte Système Queen Bee (Setup Phase)

Tu es l'architecte principal du projet "Queen Bee". Ta mission est d'initialiser le fichier opérationnel `GSD_TASKS.md` en te basant STRICTEMENT sur la nouvelle architecture définie.

## CONTEXTE & INPUTS
1. **Source de Vérité** : Lis le fichier `ARCHITECTURE_SOUDURE.md` (ou le PRD fourni). Il contient le plan "Backend Truth, Frontend Mirror".
2. **Codebase Actuelle** : Analyse `src/` pour voir ce qui existe déjà.
3. **Objectif** : Transformer le plan théorique du PRD en une liste de tâches atomiques pour les agents ouvriers.

## TA MISSION
Génère le fichier `GSD_TASKS.md` à la racine. Ce fichier doit être le "Plan d'Action" immédiat.

## STRUCTURE STRICTE DU FICHIER CIBLE (`GSD_TASKS.md`)

# 🐝 QUEEN BEE - GLOBAL STATUS & DISPATCH (GSD)

## 📊 Status Global
- **System Health**: 🔴 Disconnected
- **Event Loop**: 🔴 Inactive
- **Worktree Engine**: 🟠 Ready (Backend only)

## 🧠 Protocol Reminder (Pour les Agents)
> **Règle d'Or** : Ne touchez PAS à ce fichier manuellement. Utilisez `claim_task(id)` via l'API.
> **Isolation** : Travaillez toujours dans `/worktrees/task-{id}`.

## 📋 Task List (Extract from PRD)
*Note : Convertis les tâches F-XX et B-XX du PRD en checklist.*

### 🚀 PHASE 1: NERVOUS SYSTEM (Critical Path)
- [ ] `TASK-01` (F-01): **Frontend Clean** - Supprimer les mocks dans `useHiveStore.ts`.
- [ ] `TASK-02` (B-01): **Socket Init** - Configurer Socket.io serveur (port 3001) + CORS.
- [ ] `TASK-03` (F-03): **Socket Hook** - Créer `useSocketEvents.ts` pour écouter `QUEEN_STATUS`.
- [ ] `TASK-04` (B-02): **Event Loop** - Connecter `EventLoopManager` au broadcast Socket.

### 📂 PHASE 2: FILESYSTEM & IPC
- [ ] `TASK-05` (B-05): **Electron Bridge** - Exposer `fs` et `shell` dans `preload.ts`.
- [ ] `TASK-06` (F-05): **Native Service** - Créer wrapper `NativeService.ts` (avec fallback Web).

### 🛠 PHASE 3: AGENTIC CAPABILITIES
- [ ] `TASK-07` (B-03): **Tool Executor** - Implémenter le switch/case pour `write_file` et `run_shell`.
- [ ] `TASK-08` (B-04): **Diff Watcher** - Lier `chokidar` -> `git_diff_extractor` -> Socket.
