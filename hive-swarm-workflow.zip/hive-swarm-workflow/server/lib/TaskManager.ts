import fs from 'fs-extra';
import path from 'path';

// Assumes the GSD_TASKS.md file is in the project root, one level above the server.
const TASKS_FILE = path.resolve(process.cwd(), '../GSD_TASKS.md');

export class TaskManager {
  static async claimTask(taskId: string, agentId: string): Promise<boolean> {
    try {
      if (!fs.existsSync(TASKS_FILE)) {
        console.error(`TaskManager: File not found at ${TASKS_FILE}`);
        throw new Error(`GSD_TASKS.md file not found at ${TASKS_FILE}. Make sure it exists in your project root.`);
      }
      
      let content = await fs.readFile(TASKS_FILE, 'utf-8');

      // More robust regex to handle potential extra info in the task line
      const safeTaskId = taskId.replace(/[.*+?^${}()|[\]\]/g, '\$&');
      const pattern = new RegExp(`(- \[ \] `${safeTaskId}`)`);
      
      if (!pattern.test(content)) {
        console.warn(`TaskManager: Task ${taskId} not found or is not available (e.g., already in progress, blocked, or completed).`);
        return false;
      }

      const newContent = content.replace(
        pattern,
        `- [IN PROGRESS: ${agentId}] `${taskId}``
      );

      // Check if the content was actually changed
      if (newContent === content) {
          console.warn(`TaskManager: Failed to update content for task ${taskId}. A similar task might be causing a regex issue.`);
          return false;
      }

      await fs.writeFile(TASKS_FILE, newContent, 'utf-8');
      console.log(`TaskManager: Task ${taskId} claimed by ${agentId}`);
      return true;

    } catch (error) {
      console.error('TaskManager Error:', error);
      // Propagate error to be caught by the API handler
      throw error;
    }
  }
}
