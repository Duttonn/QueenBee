# [Project Name] - Architecture & Technical PRD

This document is the single source of truth for the technical implementation of the project.

## 1. Core Principles

-   **Backend Truth, Frontend Mirror**: The frontend should only display what the backend tells it. State changes are driven by backend events.
-   **Event-Driven**: Use WebSockets (Socket.io) for real-time communication between the backend and frontend.
-   **Componentization**: Describe your UI component structure.

## 2. Technical Breakdown

Define the atomic tasks for your agents here. Use a clear naming convention (e.g., F-01 for frontend, B-01 for backend).

### Frontend (React/Vue/etc.)

-   **F-01: [Task Title]**
    -   **File(s)**: `src/components/MyComponent.tsx`
    -   **Action**: Describe the change needed.
    -   **Validation**: How to confirm the task is done.

### Backend (Node.js/Python/etc.)

-   **B-01: [Task Title]**
    -   **File(s)**: `server/routes/myRoute.ts`
    -   **Action**: Describe the logic to implement.
    -   **Validation**: How to confirm the task is done.
