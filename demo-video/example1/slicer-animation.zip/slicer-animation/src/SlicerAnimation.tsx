import React from 'react';
import {
  AbsoluteFill,
  interpolate,
  spring,
  useCurrentFrame,
  useVideoConfig,
} from 'remotion';
import { LogoReveal } from './scenes/LogoReveal';
import { KeywordScene } from './scenes/KeywordScene';
import { DemoScene } from './scenes/DemoScene';
import { ProductCard } from './scenes/ProductCard';
import { TaglineScene } from './scenes/TaglineScene';

export const SlicerAnimation: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  // Scene timing (in frames at 30fps)
  const scenes = {
    logoReveal: { start: 0, end: 150 }, // 0-5s
    keywords: { start: 150, end: 450 }, // 5-15s
    demo: { start: 450, end: 1200 }, // 15-40s
    productCard: { start: 1200, end: 1470 }, // 40-49s
    tagline: { start: 1470, end: 1770 }, // 49-59s
  };

  return (
    <AbsoluteFill style={{ backgroundColor: '#E8EDF2' }}>
      {/* Scene 1: Logo Reveal */}
      {frame >= scenes.logoReveal.start && frame < scenes.logoReveal.end && (
        <LogoReveal frame={frame - scenes.logoReveal.start} />
      )}

      {/* Scene 2: Keywords */}
      {frame >= scenes.keywords.start && frame < scenes.keywords.end && (
        <KeywordScene frame={frame - scenes.keywords.start} />
      )}

      {/* Scene 3: Demo */}
      {frame >= scenes.demo.start && frame < scenes.demo.end && (
        <DemoScene frame={frame - scenes.demo.start} />
      )}

      {/* Scene 4: Product Card */}
      {frame >= scenes.productCard.start && frame < scenes.productCard.end && (
        <ProductCard frame={frame - scenes.productCard.start} />
      )}

      {/* Scene 5: Tagline */}
      {frame >= scenes.tagline.start && frame < scenes.tagline.end && (
        <TaglineScene frame={frame - scenes.tagline.start} />
      )}
    </AbsoluteFill>
  );
};
