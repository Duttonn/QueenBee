import { Composition } from 'remotion';
import { SlicerAnimation } from './SlicerAnimation';

export const RemotionRoot: React.FC = () => {
  return (
    <>
      <Composition
        id="SlicerAnimation"
        component={SlicerAnimation}
        durationInFrames={1770} // 59 seconds at 30fps
        fps={30}
        width={1920}
        height={1080}
        defaultProps={{}}
      />
    </>
  );
};
