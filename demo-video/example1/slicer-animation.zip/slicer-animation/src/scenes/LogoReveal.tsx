import React from 'react';
import { AbsoluteFill, interpolate, spring, useVideoConfig } from 'remotion';

interface LogoRevealProps {
  frame: number;
}

export const LogoReveal: React.FC<LogoRevealProps> = ({ frame }) => {
  const { fps } = useVideoConfig();

  // Animation timing
  const opacity = interpolate(frame, [0, 30], [0, 1], {
    extrapolateRight: 'clamp',
  });

  const scale = spring({
    frame,
    fps,
    config: {
      damping: 200,
    },
    from: 0.8,
    to: 1,
  });

  return (
    <AbsoluteFill
      style={{
        justifyContent: 'center',
        alignItems: 'center',
        opacity,
        transform: `scale(${scale})`,
      }}
    >
      <div style={{ display: 'flex', alignItems: 'center', gap: '20px' }}>
        {/* Logo Icon */}
        <div
          style={{
            width: '100px',
            height: '100px',
            backgroundColor: '#1A1A1A',
            borderRadius: '24px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            position: 'relative',
          }}
        >
          <svg width="60" height="60" viewBox="0 0 60 60">
            <text
              x="30"
              y="40"
              fontSize="48"
              fontWeight="bold"
              fill="#FF1654"
              textAnchor="middle"
              fontFamily="sans-serif"
            >
              S
            </text>
            <line
              x1="10"
              y1="50"
              x2="50"
              y2="10"
              stroke="#FF1654"
              strokeWidth="4"
              strokeLinecap="round"
            />
          </svg>
        </div>

        {/* Logo Text */}
        <div style={{ display: 'flex', fontSize: '80px', fontWeight: 700 }}>
          <span style={{ color: '#1A1A1A', fontFamily: 'sans-serif' }}>
            slicer
          </span>
          <span style={{ color: '#FF1654', fontFamily: 'sans-serif' }}>
            .dev
          </span>
        </div>
      </div>
    </AbsoluteFill>
  );
};
