import React from 'react';
import { AbsoluteFill, interpolate, spring, useVideoConfig } from 'remotion';

interface DemoSceneProps {
  frame: number;
}

export const DemoScene: React.FC<DemoSceneProps> = ({ frame }) => {
  const { fps } = useVideoConfig();

  // Scene transitions
  const showClickToCopy = frame >= 0 && frame < 300;
  const showVibeCoding = frame >= 300;

  return (
    <AbsoluteFill>
      {/* Click to Copy Scene */}
      {showClickToCopy && (
        <ClickToCopyScene frame={frame} fps={fps} />
      )}

      {/* Vibecoding Tools Scene */}
      {showVibeCoding && (
        <VibecodingScene frame={frame - 300} fps={fps} />
      )}
    </AbsoluteFill>
  );
};

const ClickToCopyScene: React.FC<{ frame: number; fps: number }> = ({
  frame,
  fps,
}) => {
  const cardY = spring({
    frame,
    fps,
    from: 100,
    to: 0,
    config: { damping: 200 },
  });

  const opacity = interpolate(frame, [0, 20], [0, 1], {
    extrapolateRight: 'clamp',
  });

  const buttonScale = interpolate(frame, [150, 170], [1, 1.05], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  return (
    <AbsoluteFill
      style={{
        justifyContent: 'center',
        alignItems: 'center',
        opacity,
      }}
    >
      {/* Title */}
      <div
        style={{
          position: 'absolute',
          top: '15%',
          fontSize: '48px',
          fontFamily: 'sans-serif',
          fontWeight: 600,
        }}
      >
        <span style={{ color: '#1A1A1A' }}>click to </span>
        <span style={{ color: '#FF1654' }}>copy</span>
      </div>

      {/* Card */}
      <div
        style={{
          width: '900px',
          backgroundColor: '#7A7A7A',
          borderRadius: '24px',
          padding: '40px',
          transform: `translateY(${cardY}px)`,
          boxShadow: '0 20px 60px rgba(0,0,0,0.2)',
        }}
      >
        <h2
          style={{
            fontSize: '32px',
            fontWeight: 700,
            marginBottom: '30px',
            color: '#1A1A1A',
            fontFamily: 'sans-serif',
          }}
        >
          AI design tools
        </h2>

        {/* Tool Items */}
        {[
          {
            name: 'Slicer.dev',
            desc: 'Chrome extension to copy interactive web components as...',
            tags: ['Developer Tools', 'Chrome Extension'],
            votes: [24, 412],
          },
          {
            name: 'Figma',
            desc: 'Collaborative design tool for teams to build products',
            tags: ['Design', 'UI/UX'],
            votes: [0, 0],
          },
          {
            name: 'Framer',
            desc: 'Site builder for creative teams. Design and publish sites wit...',
            tags: ['Website Builder', 'AI Tools'],
            votes: [89, 1240],
          },
        ].map((tool, index) => (
          <ToolItem key={index} tool={tool} delay={index * 10} frame={frame} />
        ))}
      </div>

      {/* Floating Button */}
      {frame > 100 && (
        <div
          style={{
            position: 'absolute',
            right: '15%',
            top: '50%',
            backgroundColor: '#0084FF',
            color: 'white',
            padding: '20px 50px',
            borderRadius: '50px',
            fontSize: '28px',
            fontWeight: 600,
            fontFamily: 'sans-serif',
            transform: `scale(${buttonScale})`,
            boxShadow: '0 10px 40px rgba(0,132,255,0.4)',
            cursor: 'pointer',
          }}
        >
          click to copy
        </div>
      )}
    </AbsoluteFill>
  );
};

const ToolItem: React.FC<{
  tool: any;
  delay: number;
  frame: number;
}> = ({ tool, delay, frame }) => {
  const opacity = interpolate(frame, [delay, delay + 15], [0, 1], {
    extrapolateRight: 'clamp',
  });

  return (
    <div
      style={{
        backgroundColor: 'white',
        padding: '20px',
        borderRadius: '12px',
        marginBottom: '15px',
        display: 'flex',
        alignItems: 'center',
        gap: '20px',
        opacity,
        border: tool.name === 'Slicer.dev' ? '3px solid #0084FF' : 'none',
      }}
    >
      <div
        style={{
          width: '60px',
          height: '60px',
          backgroundColor: '#1A1A1A',
          borderRadius: '12px',
        }}
      />
      <div style={{ flex: 1 }}>
        <h3
          style={{
            fontSize: '24px',
            fontWeight: 700,
            marginBottom: '8px',
            color: '#1A1A1A',
            fontFamily: 'sans-serif',
          }}
        >
          {tool.name}
        </h3>
        <p
          style={{
            fontSize: '16px',
            color: '#666',
            marginBottom: '10px',
            fontFamily: 'sans-serif',
          }}
        >
          {tool.desc}
        </p>
        <div style={{ display: 'flex', gap: '10px' }}>
          {tool.tags.map((tag: string, i: number) => (
            <span
              key={i}
              style={{
                fontSize: '14px',
                color: '#888',
                fontFamily: 'sans-serif',
              }}
            >
              🔗 {tag}
            </span>
          ))}
        </div>
      </div>
      {tool.votes[0] > 0 && (
        <div style={{ display: 'flex', gap: '20px', fontSize: '18px' }}>
          <span>💬 {tool.votes[0]}</span>
          <span>🔺 {tool.votes[1]}</span>
        </div>
      )}
    </div>
  );
};

const VibecodingScene: React.FC<{ frame: number; fps: number }> = ({
  frame,
  fps,
}) => {
  const opacity = interpolate(frame, [0, 20], [0, 1], {
    extrapolateRight: 'clamp',
  });

  return (
    <AbsoluteFill
      style={{
        justifyContent: 'center',
        alignItems: 'center',
        opacity,
      }}
    >
      {/* Title */}
      <div
        style={{
          position: 'absolute',
          top: '20%',
          fontSize: '56px',
          fontFamily: 'sans-serif',
          fontWeight: 600,
          textAlign: 'center',
        }}
      >
        <span style={{ color: '#1A1A1A' }}>or any </span>
        <span style={{ color: '#FF1654' }}>vibecoding</span>
        <span style={{ color: '#1A1A1A' }}> tool</span>
      </div>

      {/* Copy Slice Button */}
      <div
        style={{
          backgroundColor: '#FF1654',
          color: 'white',
          padding: '25px 60px',
          borderRadius: '16px',
          fontSize: '32px',
          fontWeight: 700,
          fontFamily: 'sans-serif',
          display: 'flex',
          alignItems: 'center',
          gap: '20px',
          marginBottom: '40px',
          boxShadow: '0 10px 40px rgba(255,22,84,0.4)',
        }}
      >
        <span>📋 Copy slice</span>
        <div
          style={{
            width: '50px',
            height: '50px',
            backgroundColor: '#1A1A1A',
            borderRadius: '8px',
          }}
        />
        <span>▼</span>
      </div>

      {/* Tool Icons */}
      <div
        style={{
          display: 'flex',
          gap: '20px',
          backgroundColor: 'white',
          padding: '30px',
          borderRadius: '20px',
          boxShadow: '0 10px 40px rgba(0,0,0,0.1)',
          position: 'relative',
        }}
      >
        {[0, 1, 2, 3].map((i) => {
          const iconOpacity = interpolate(
            frame,
            [30 + i * 10, 45 + i * 10],
            [0, 1],
            { extrapolateRight: 'clamp' }
          );

          return (
            <div
              key={i}
              style={{
                width: '80px',
                height: '80px',
                backgroundColor: i === 3 ? '#0084FF' : '#1A1A1A',
                borderRadius: '16px',
                opacity: iconOpacity,
              }}
            />
          );
        })}

        {/* Tooltip */}
        {frame > 80 && (
          <div
            style={{
              position: 'absolute',
              bottom: '-60px',
              right: '0',
              backgroundColor: '#FF1654',
              color: 'white',
              padding: '15px 25px',
              borderRadius: '12px',
              fontSize: '20px',
              fontFamily: 'sans-serif',
              fontWeight: 600,
              boxShadow: '0 5px 20px rgba(255,22,84,0.3)',
            }}
          >
            📄 prompt.tsx
          </div>
        )}
      </div>
    </AbsoluteFill>
  );
};
