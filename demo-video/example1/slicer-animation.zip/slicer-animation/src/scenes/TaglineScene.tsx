import React from 'react';
import { AbsoluteFill, interpolate } from 'remotion';

interface TaglineSceneProps {
  frame: number;
}

export const TaglineScene: React.FC<TaglineSceneProps> = ({ frame }) => {
  const logoOpacity = interpolate(frame, [0, 20], [0, 1], {
    extrapolateRight: 'clamp',
  });

  const taglineOpacity = interpolate(frame, [20, 40], [0, 1], {
    extrapolateRight: 'clamp',
  });

  // Progressive reveal of "implementation"
  const implementationOpacity = interpolate(frame, [60, 100], [0.3, 1], {
    extrapolateRight: 'clamp',
  });

  return (
    <AbsoluteFill
      style={{
        justifyContent: 'center',
        alignItems: 'center',
        flexDirection: 'column',
        gap: '80px',
      }}
    >
      {/* Logo */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: '20px',
          opacity: logoOpacity,
        }}
      >
        <div
          style={{
            width: '80px',
            height: '80px',
            backgroundColor: '#1A1A1A',
            borderRadius: '20px',
          }}
        />
        <div style={{ display: 'flex', fontSize: '64px', fontWeight: 700 }}>
          <span style={{ color: '#1A1A1A', fontFamily: 'sans-serif' }}>
            slicer
          </span>
          <span style={{ color: '#FF1654', fontFamily: 'sans-serif' }}>
            .dev
          </span>
        </div>
      </div>

      {/* Tagline */}
      <div
        style={{
          fontSize: '72px',
          fontWeight: 700,
          fontFamily: 'sans-serif',
          textAlign: 'center',
          opacity: taglineOpacity,
        }}
      >
        <span style={{ color: '#1A1A1A' }}>Web inspiration to </span>
        <span
          style={{
            color: '#1A1A1A',
            opacity: implementationOpacity,
          }}
        >
          implementation
        </span>
        <span style={{ color: '#1A1A1A' }}>,</span>
      </div>
    </AbsoluteFill>
  );
};
