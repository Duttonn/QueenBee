import React from 'react';
import { AbsoluteFill, interpolate, spring, useVideoConfig } from 'remotion';

interface ProductCardProps {
  frame: number;
}

export const ProductCard: React.FC<ProductCardProps> = ({ frame }) => {
  const { fps } = useVideoConfig();

  const scale = spring({
    frame,
    fps,
    from: 0.9,
    to: 1,
    config: { damping: 200 },
  });

  const opacity = interpolate(frame, [0, 20], [0, 1], {
    extrapolateRight: 'clamp',
  });

  return (
    <AbsoluteFill
      style={{
        justifyContent: 'center',
        alignItems: 'center',
        opacity,
      }}
    >
      <div
        style={{
          width: '1000px',
          backgroundColor: 'white',
          borderRadius: '24px',
          padding: '50px',
          boxShadow: '0 20px 80px rgba(0,0,0,0.15)',
          transform: `scale(${scale})`,
          display: 'flex',
          alignItems: 'center',
          gap: '30px',
        }}
      >
        {/* Logo */}
        <div
          style={{
            width: '100px',
            height: '100px',
            backgroundColor: '#1A1A1A',
            borderRadius: '20px',
            flexShrink: 0,
          }}
        />

        {/* Content */}
        <div style={{ flex: 1 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '15px', marginBottom: '15px' }}>
            <h2
              style={{
                fontSize: '36px',
                fontWeight: 700,
                color: '#FF1654',
                fontFamily: 'sans-serif',
                margin: 0,
              }}
            >
              Slicer.dev
            </h2>
            <span style={{ fontSize: '24px', color: '#888' }}>↗</span>
          </div>

          <p
            style={{
              fontSize: '20px',
              color: '#666',
              marginBottom: '20px',
              fontFamily: 'sans-serif',
              lineHeight: 1.5,
            }}
          >
            Chrome extension to copy interactive web components as...
          </p>

          <div style={{ display: 'flex', gap: '15px', fontSize: '16px' }}>
            <span style={{ color: '#888', fontFamily: 'sans-serif' }}>
              🔗 Developer Tools
            </span>
            <span style={{ color: '#888', fontFamily: 'sans-serif' }}>
              · Chrome Extension
            </span>
          </div>
        </div>

        {/* Metrics */}
        <div style={{ display: 'flex', gap: '30px', fontSize: '24px', color: '#1A1A1A' }}>
          <div style={{ textAlign: 'center' }}>
            <div style={{ fontSize: '28px', fontWeight: 700 }}>💬</div>
            <div style={{ fontWeight: 700 }}>24</div>
          </div>
          <div style={{ textAlign: 'center' }}>
            <div style={{ fontSize: '28px', fontWeight: 700 }}>🔺</div>
            <div style={{ fontWeight: 700 }}>412</div>
          </div>
        </div>
      </div>
    </AbsoluteFill>
  );
};
