import React from 'react';
import { AbsoluteFill, interpolate } from 'remotion';

interface KeywordSceneProps {
  frame: number;
}

export const KeywordScene: React.FC<KeywordSceneProps> = ({ frame }) => {
  // Multiple keywords with timing
  const keywords = [
    { text: 'websites', start: 0, end: 90 },
    { text: 'components', start: 90, end: 180 },
    { text: 'inspiration', start: 180, end: 270 },
  ];

  return (
    <AbsoluteFill
      style={{
        justifyContent: 'center',
        alignItems: 'center',
      }}
    >
      {keywords.map((keyword, index) => {
        if (frame < keyword.start || frame >= keyword.end) return null;

        const localFrame = frame - keyword.start;
        const opacity = interpolate(
          localFrame,
          [0, 15, keyword.end - keyword.start - 15, keyword.end - keyword.start],
          [0, 1, 1, 0],
          { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' }
        );

        const translateY = interpolate(
          localFrame,
          [0, 20],
          [30, 0],
          { extrapolateRight: 'clamp' }
        );

        return (
          <div
            key={keyword.text}
            style={{
              fontSize: '120px',
              fontWeight: 700,
              color: '#FF1654',
              fontFamily: 'sans-serif',
              opacity,
              transform: `translateY(${translateY}px)`,
            }}
          >
            {keyword.text}
          </div>
        );
      })}
    </AbsoluteFill>
  );
};
